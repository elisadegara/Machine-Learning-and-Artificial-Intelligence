import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import torch


from data_loader_reduced import NYUv2
from data_loader import NYUDataset
from torchvision import transforms


def get_data(reduced=True, train_transformation = None, test_transformation = None):
    '''
    It returns train_data, and test_data. If reduced = True (default) then it gets the reduced dataset, else the complete one.

    Args:
        reduced (bool): if True, gets the reduced dataset, else the complete one
        transform (transforms object): series of transformation to apply to the dataset. If None then ToTensor() is applied.
    '''
    if reduced:
        train_data = NYUv2(root="./data_reduced/NYUv2", train = True, download=True, rgb_transform=train_transformation, depth_transform=train_transformation)
        test_data = NYUv2(root="./data_reduced/NYUv2", train = False, download=True, rgb_transform=test_transformation, depth_transform=test_transformation)
    else:
        train_data = NYUDataset("./data/nyudepthv2/train", 'train', transform = train_transformation)
        test_data = NYUDataset("./data/nyudepthv2/val", 'val', transform = test_transformation)

    return train_data, test_data


def show_depthmap(depth_map):
    '''
    It shows the depth map

    Args:
        depth_map (torch.Tensor): tensor corresponding to the depth map
    '''
    plt.imshow(depth_map.squeeze())
    plt.axis("off")
    plt.show()


def show_image(image):
    '''
    It shows the image

    Args:
        image (torch.Tensor): 3-d tensor corresponding to the image.
    '''
    image = np.transpose(image, (1, 2, 0))

    plt.imshow(image)
    plt.axis("off")
    plt.show()


def check(image, depth_map, prediction):
    '''
    It shows the image, the depth map, and the prediction

    Args:
        image (torch.Tensor): 3-d tensor corresponding to the image.
        depth_map (torch.Tensor): tensor corresponding to the depth map
        prediction (torch.Tensor): tensor corresponding to the prediction
    '''
    image = image.permute(1, 2, 0).numpy()

    fig, ax = plt.subplots(1,3, figsize=(10,5))
    ax[0].imshow(image)
    ax[0].axis('off')
    ax[1].imshow(depth_map.squeeze())
    ax[1].axis('off')
    ax[2].imshow(prediction.squeeze())
    ax[2].axis('off')

    plt.show()




def plot_loss(train_loss, test_loss, scores):
    fig, axes = plt.subplots(len(scores) + 1, 1, figsize=(8, 5 * (len(scores) + 1)))

    # Plotting the loss values
    axes[0].plot(range(1, len(train_loss) + 1), train_loss, marker='o', linestyle='-', color='b', label=scores[0])
    axes[0].set_title(scores[0])
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].legend()
    axes[0].grid(False)

    # Plotting the dictionary values
    i = 1
    for label, values in test_loss.items():
        axes[i].plot(range(1, len(values) + 1), values, marker='o', linestyle='-', label=label)
        axes[i].set_title(label)
        axes[i].set_xlabel('Epoch')
        axes[i].set_ylabel('Metrics')
        axes[i].legend()
        axes[i].grid(False)
        i = i+1

    for ax in axes:
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    # Adjust layout and display the plots
    plt.tight_layout()
    plt.show()



def print_images(images, depth_masks, predictions):
    fig, ax = plt.subplots(len(images),len(predictions) + 2, figsize=(20,10))

    for i in range(len(images)):
        image = images[i].permute(1, 2, 0).numpy()
        ax[0].imshow(image)
        ax[0].axis('off')

        ax[1].imshow(depth_masks[i].squeeze())
        ax[1].axis('off')


    plt.show()

