import torch
import os

import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt

from collections import defaultdict
from data_loader_reduced import NYUv2
from data_loader import NYUDataset


def train_model(model, train_loader, test_loader, num_epochs, device, criterion, scores, optimizer, verbose=True, start_epoch=0, train_loss = [], test_loss = defaultdict(list)):
    save_dir = './checkpoints/' + model.name
    os.makedirs(save_dir, exist_ok=True)

    train_loss_over_time = train_loss
    test_loss_over_time = test_loss


    predictions = []

    model.to(device)
    
    for epoch in range(start_epoch, num_epochs):

        model.train()
        total_train_loss = 0.0

        for batch_idx, (images, depth_maps) in enumerate(train_loader):
            
            images = images.to(device)
            depth_maps = depth_maps.to(device)
            
            optimizer.zero_grad()
            
            outputs = model(images)
            loss = criterion(outputs, depth_maps)

            total_train_loss += loss.item()
            
            loss.backward()
            optimizer.step()

            if verbose:
                print(f"Batch [{batch_idx+1}/{len(train_loader)}], Loss: {loss.item():.4f}")

        avg_train_loss = total_train_loss / len(train_loader)
        train_loss_over_time.append(avg_train_loss)

        model.eval()
        avg_test_loss = {str(score): 0.0 for score in scores}
        
        with torch.no_grad():
            for images, depth_maps in test_loader:
                images = images.to(device)
                depth_maps = depth_maps.to(device)
                
                outputs = model(images)
                
                for score in scores:
                    avg_test_loss[str(score)] += score(outputs, depth_maps).item() / len(test_loader)

                if epoch == num_epochs - 1:
                    predictions.append(outputs.cpu().numpy())

            for score in scores:
                test_loss_over_time[str(score)].append(avg_test_loss[str(score)])


        checkpoint = {
            'epoch': epoch + 1,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'train_loss': train_loss_over_time,
            'test_loss': test_loss_over_time
        }
        checkpoint_path = os.path.join(save_dir, f'epoch_{epoch+1}.pth')
        torch.save(checkpoint, checkpoint_path)
        if epoch != 0:
            os.remove('./checkpoints/' + model.name + f'/epoch_{epoch}.pth')

    
        print("\033[91m" + f"Epoch [{epoch+1}/{num_epochs}], Train Loss: {avg_train_loss:.4f}"  + "\033[0m")
        to_print = ""
        for score in scores:
            to_print += str(score) + ": " + f"{avg_test_loss[str(score)]:.4f}" + "; "
        print("\033[91m" + "Test Loss: " + to_print[:-2] + "\033[0m")
    
    predictions = np.concatenate(predictions, axis=0)

    return model, predictions, train_loss_over_time, test_loss_over_time


def test_pretrained_model(model, path_to_weights, test_loader, num_epochs, device, scores, start_epoch=0, test_loss=defaultdict(list)):
    '''
    Tests the already trained model on test_dataset.
    
    Args:
        path_to_weights (str): file name of the pretrained model.
    '''
    
    model.to(device)
    state_dict = torch.load(path_to_weights, map_location=torch.device(device))
    model.load_state_dict(state_dict['model_state_dict'])
    test_loss_over_time = test_loss

    predictions = []
    
    for epoch in range(start_epoch, num_epochs):

        model.eval()
        avg_test_loss = {score: 0.0 for score in scores}

        with torch.no_grad():
            for images, depth_maps in test_loader:
                images = images.to(device)
                depth_maps = depth_maps.to(device)
                
                outputs = model(images)
                
                for score in scores:
                    avg_test_loss[score] += score(outputs, depth_maps).item() / len(test_loader)

                if epoch == num_epochs - 1:
                    predictions.append(outputs.cpu().numpy())

            for score in scores:
                test_loss_over_time[str(score)].append(avg_test_loss[score])
         
        to_print = ""
        for score in scores:
            to_print += str(score) + ": " + f"{avg_test_loss[score]:.4f}" + "; "
        print("\033[91m" + "Test Loss: " + to_print[:-2] + "\033[0m")
    
    predictions = np.concatenate(predictions, axis=0)

    return predictions, test_loss_over_time


def check(image, depth_map, prediction):
    '''
    It shows the image, the depth map, and the prediction

    Args:
        image (torch.Tensor): 3-d tensor corresponding to the image.
        depth_map (torch.Tensor): tensor corresponding to the depth map
        prediction (torch.Tensor): tensor corresponding to the prediction
    '''

    image = image.permute(1, 2, 0).numpy()

    fig, ax = plt.subplots(1,3, figsize=(10,5))

    ax[0].imshow(image)
    ax[0].axis('off')
    ax[0].set_title('Image')

    ax[1].imshow(depth_map.squeeze())
    ax[1].axis('off')
    ax[1].set_title('Ground Truth')

    ax[2].imshow(prediction.squeeze())
    ax[2].axis('off')
    ax[2].set_title('Prediction')

    plt.show()


def compare(image, depth_map, predictions):
    '''
    It shows the image, the depth map, and the prediction

    Args:
        image (torch.Tensor): 3-d tensor corresponding to the image.
        depth_map (torch.Tensor): tensor corresponding to the depth map
        predictions (List(torch.Tensor)): list of tensors corresponding predictions of different models
    '''

    image = image.permute(1, 2, 0).numpy()


    fig, ax = plt.subplots(1, 2 + len(predictions), figsize=(10,5))

    ax[0].imshow(image)
    ax[0].axis('off')
    ax[0].set_title('Image')

    ax[1].imshow(depth_map.squeeze())
    ax[1].axis('off')
    ax[1].set_title('Ground Truth')

    for i in range(len(predictions)):
        ax[2+i].imshow(predictions[i].squeeze())
        ax[2+i].axis('off')
        ax[2+i].set_title(f'Prediction {i+1}')
        
    plt.show()


def get_data(reduced=True, train_transformation = None, test_transformation = None):
    '''
    It returns train_data, and test_data. If reduced = True (default) then it gets the reduced dataset, else the complete one.

    Args:
        reduced (bool): if True, gets the reduced dataset, else the complete one
        transform (transforms object): series of transformation to apply to the dataset. If None then ToTensor() is applied.
    '''
    if reduced:
        train_data = NYUv2(root="./data_reduced/NYUv2", train = True, download=True, rgb_transform=train_transformation, depth_transform=train_transformation)
        test_data = NYUv2(root="./data_reduced/NYUv2", train = False, download=True, rgb_transform=test_transformation, depth_transform=test_transformation)
    else:
        train_data = NYUDataset("./data/nyudepthv2/train", 'train', transform = train_transformation)
        test_data = NYUDataset("./data/nyudepthv2/val", 'val', transform = test_transformation)

    return train_data, test_data
