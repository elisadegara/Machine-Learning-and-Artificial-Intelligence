import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F


class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()
        self.upconv1 = nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                                     nn.Conv2d(512, 256, kernel_size=3, padding=1, stride=1)) #256x16x16
        
        self.conv1 = nn.Conv2d(256, 256, kernel_size=3, padding=1) #256x16x16
        self.upconv2 = nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                                     nn.Conv2d(256, 128, kernel_size=3, padding=1, stride=1)) #128x32x32
 
        self.conv2 = nn.Conv2d(128, 128, kernel_size=3, padding=1)#128x32x32
        self.upconv3 = nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                                     nn.Conv2d(128, 64, kernel_size=3, padding=1, stride=1))#64x64x64
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, padding=1) #64x64x64
        self.upconv4 = nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                                     nn.Conv2d(64, 32, kernel_size=3, padding=1, stride=1))#32x128x128
        self.conv4 = nn.Conv2d(32, 32, kernel_size=3, padding=1) ##32x128x128
        
        self.conv5 = nn.Conv2d(32, 1, kernel_size=3, padding=1)

        self.skip_conv_1 = nn.Conv2d(256, 128, kernel_size=3, padding=1) 
        self.upsample_1 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True) 
        self.skip_conv_2 = nn.Conv2d(128, 64, kernel_size=3, padding=1) 
        self.upsample_2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.skip_conv_3 = nn.Conv2d(64, 32, kernel_size=3, padding=1) 
        self.upsample_3 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        self.bn1 = nn.BatchNorm2d(256)
        self.bn2 = nn.BatchNorm2d(128)
        self.bn3 = nn.BatchNorm2d(64)
        self.bn4 = nn.BatchNorm2d(32)


    def forward(self, x):
        x = F.relu(self.upconv1(x)) #256x16x16
        x = F.relu(self.conv1(x)) #256x16x16
        skip_x_1 = x #256x16x16

        x = F.relu(self.upconv2(x))
        x = F.relu(self.conv2(x)) #128x32x32
        skip_x_1 = self.upsample_1(F.relu(self.skip_conv_1(skip_x_1))) #128x32x32
        x = self.bn2(x + skip_x_1) 

        skip_x_2 = x
        x = F.relu(self.upconv3(x)) #64x64x64
        x = F.relu(self.conv3(x)) #64x64x64
        skip_x_2 = self.upsample_2(F.relu(self.skip_conv_2(skip_x_2))) #64x64x64
        x = self.bn3(x + skip_x_2) #64x64x64

        skip_x_3 = x #64x64x64
        x = F.relu(self.upconv4(x)) #32x128x128
        x = F.relu(self.conv4(x)) #32x128x128
        skip_x_3 = self.upsample_3(F.relu(self.skip_conv_3(skip_x_3))) #32x128x128
        x = self.bn4(x + skip_x_3)

        x = F.relu(self.conv5(x)) #1x128x128
        return x
    

class DE_gio_noskip(nn.Module):
    def __init__(self):
        super(DE_gio_noskip, self).__init__()

        self.name = "DE_gio_noskip"
        
        resnet50 = models.resnet50(pretrained=True)
        self.encoder = nn.Sequential(*list(resnet50.children())[:-3])
        self.in_between = nn.Sequential(nn.Conv2d(in_channels=1024, out_channels = 512, kernel_size=1, stride=1, padding=0, bias=False),
                                            nn.BatchNorm2d(512))

        self.decoder = Decoder()

    def forward(self, x):
        x = self.encoder(x)
        x = self.in_between(x)
        x = self.decoder(x)
        return x







