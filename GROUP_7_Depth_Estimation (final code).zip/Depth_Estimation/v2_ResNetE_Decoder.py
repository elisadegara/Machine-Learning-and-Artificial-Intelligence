import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
import torch


class ResNetE_Decoder(nn.Module):
    def __init__(self):
        super(ResNetE_Decoder, self).__init__()
        
        self.name = "ResNetE_Decoder"

        resnet34 = models.resnet34(pretrained=True)
        self.layer0 = nn.Sequential(resnet34.conv1, resnet34.bn1, resnet34.relu, resnet34.maxpool)
        self.layer1 = resnet34.layer1
        self.layer2 = resnet34.layer2
        self.layer3 = resnet34.layer3
        self.layer4 = resnet34.layer4

        self.upconv1 = nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1) #256x8x8
        self.conv1 = nn.Conv2d(256, 256, kernel_size=3, padding=1) #256x8x8
        self.upconv2 = nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1) #128x16x16
        self.conv2 = nn.Conv2d(128, 128, kernel_size=3, padding=1) #128x16x16
        self.upconv3 = nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1) #64x32x32
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, padding=1) #64x32x32
        self.upconv4 = nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1) #32x64x64
        self.conv4 = nn.Conv2d(32, 32, kernel_size=3, padding=1) #32x64x64
        self.upconv5 = nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1) #16x128x128
        self.conv5 = nn.Conv2d(16, 16, kernel_size=3, padding=1) #16x128x128
        
        self.conv6 = nn.Conv2d(16, 8, kernel_size=5, padding=2) #8x128x128
        self.conv7 = nn.Conv2d(8, 4, kernel_size=7, padding=3) #4x128x128
        self.conv8 = nn.Conv2d(4, 2, kernel_size=9, padding=4) #2x128x128
        self.conv9 = nn.Conv2d(2, 1, kernel_size=11, padding=5) #1x128x128

        self.conv10 = nn.Conv2d(1, 1, kernel_size=3, padding=1, stride=2) #1x64x64
        self.upsample = nn.ConvTranspose2d(1, 1, kernel_size=4, stride=2, padding=1) #1x128x128

        self.skip_conv_1 = nn.Conv2d(256, 64, kernel_size=3, padding=1) #64x8x8
        self.upsample_1 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True) #64x32x32
        self.skip_conv_2 = nn.Conv2d(64, 16, kernel_size=3, padding=1) #16x32x32
        self.upsample_2 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True) #16x128x128
        self.skip_conv_3 = nn.Conv2d(16, 1, kernel_size=3, padding=1) #1x128x128

        self.skip_conv_0 = nn.Conv2d(3, 1, kernel_size=3, padding=1)

        self.bn1 = nn.BatchNorm2d(256)
        self.bn2 = nn.BatchNorm2d(128)
        self.bn3 = nn.BatchNorm2d(64)
        self.bn4 = nn.BatchNorm2d(32)
        self.bn5 = nn.BatchNorm2d(16)
        self.bn6 = nn.BatchNorm2d(8)
        self.bn7 = nn.BatchNorm2d(4)
        self.bn8 = nn.BatchNorm2d(2)
        self.bn9 = nn.BatchNorm2d(1)
        
        self.final_conv = nn.Conv2d(5, 1, kernel_size=3, padding=1)

    def forward(self, x):
        skip_x_0 = x #3x128x128
        
        x = self.layer0(x) #64x32x32
        x_skip_1 = x
        x = self.layer1(x) #64x32x32
        x_skip_2 = x
        x = self.layer2(x) #128x16x16
        x_skip_3 = x
        x = self.layer3(x) #256x8x8
        x_skip_4 = x
        x = self.layer4(x) #512x4x4


        x = F.relu(self.upconv1(x)) #256x8x8
        x = F.relu(self.conv1(x)) #256x8x8
        x = self.bn1(x + x_skip_4)


        x = F.relu(self.upconv2(x)) #128x16x16
        x = F.relu(self.conv2(x)) #128x16x16
        x = self.bn2(x + x_skip_3)

        
        x = F.relu(self.upconv3(x)) #64x32x32
        x = F.relu(self.conv3(x)) #64x32x32
        x = self.bn3(x + x_skip_2)
        
        x = self.bn3(x + x_skip_1) #64x32x32
        
        x = F.relu(self.upconv4(x)) #32x64x64
        x = F.relu(self.conv4(x)) #32x64x6x64

        x = F.relu(self.upconv5(x)) #16x128x128
        x = F.relu(self.conv5(x))#16x128x128
        
        x = self.bn5(x) #16x128x128
        skip_x_3 = x #16x128x128

        x = F.relu(self.conv6(x)) #8x128x128

        x = F.relu(self.conv7(x)) #4x128x128

        x = F.relu(self.conv8(x)) #2x128x128

        x = F.relu(self.conv9(x)) #1x128x128

        skip_x_3 = F.relu(self.skip_conv_3(skip_x_3)) #1x128x128
        x = torch.cat([x, skip_x_0, skip_x_3], dim=1) #5x128x128

        x = self.final_conv(x) #1x128x128

        return x
