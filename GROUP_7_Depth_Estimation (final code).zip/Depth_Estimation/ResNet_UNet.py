import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
import torch

from torchvision.models.resnet import resnet50, ResNet50_Weights
from torchvision.models.resnet import resnet18, ResNet18_Weights
from torchvision.models.resnet import resnet34, ResNet34_Weights

class Conv2Layers(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv2layer = nn.Sequential(nn.Conv2d(in_channels = in_channels,
                                                  out_channels = in_channels,
                                                  kernel_size = 3,
                                                  stride = 1,
                                                  padding = 1),
                                        nn.BatchNorm2d(in_channels),
                                        nn.ReLU(inplace = True),
                                        nn.Conv2d(in_channels=in_channels,
                                               out_channels=out_channels,
                                               kernel_size=3,
                                               stride=1,
                                               padding=1),
                                        nn.BatchNorm2d(out_channels),
                                        nn.ReLU(inplace = True)
                                        )
    def forward(self, x):
        return self.conv2layer(x)

class UpblockUNet(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.conv = Conv2Layers(in_channels, out_channels) 
   
    def forward(self, x1, x2):
        x1 = self.up(x1)
        x = torch.cat([x2, x1], dim=1)
        x = self.conv(x)
        return x   


class ResNet_UNet(nn.Module):
    def __init__(self, fixed_weights = False, pretrained = True):
        super().__init__()

        self.name = "ResNet_UNet"
        
        resnet = resnet50(weights=ResNet50_Weights.DEFAULT if pretrained == True else None)
        self.in_between_in_ch = 2048
        self.in_between = nn.Sequential(nn.Conv2d(in_channels=self.in_between_in_ch, out_channels = 1024, kernel_size=1, stride=1, padding=0, bias = False),
                                        nn.ReLU())
        
        self.decod1 = UpblockUNet(in_channels=1024 + 1024, out_channels=512) 
        self.decod2 = UpblockUNet(in_channels=512 + 512,  out_channels=256)
        self.decod3 = UpblockUNet(in_channels=256 + 256,  out_channels=128)
        self.decod4 = UpblockUNet(in_channels=128 + 64,  out_channels=64)
        
        self.resnet00 = nn.Sequential(resnet.conv1, 
                                    resnet.bn1, 
                                    resnet.relu)
        self.resnet0 = resnet.maxpool
                                    
        self.resnet1=resnet.layer1
        self.resnet2=resnet.layer2
        self.resnet3=resnet.layer3
        self.resnet4=resnet.layer4                    
        
        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.outconv = nn.Conv2d(in_channels=64, out_channels = 1, kernel_size=3, stride=1, padding=1, bias=False)

    def forward(self, x):
        x0 = self.resnet00(x)
        x1 = self.resnet0(x0)
        x2 = self.resnet1(x1)
        x3 = self.resnet2(x2)
        x4 = self.resnet3(x3)
        x5 = self.resnet4(x4)

        x = self.in_between(x5)

        x = self.decod1(x, x4)
        x = self.decod2(x, x3)
        x = self.decod3(x, x2)
        x = self.decod4(x, x0)
        x = self.upsample(x)
        x = self.outconv(x)
        return x