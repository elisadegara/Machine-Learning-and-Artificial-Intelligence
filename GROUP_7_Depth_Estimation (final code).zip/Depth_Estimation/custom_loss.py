import torch
from torchvision import transforms
import numpy as np
import torch.nn as nn

def AbsoluteRelativeDifference(depth, depth_pred):                 									
	loss = torch.mean(torch.abs(depth - depth_pred) / depth_pred)
	return loss

def L1(depth, depth_pred):
	loss = torch.mean(torch.abs(depth - depth_pred))
	return loss

def L1_log(depth, depth_pred):
	loss = torch.mean(torch.abs(torch.log(depth) - torch.log(depth_pred)))
	return loss

def SquaredRelativeDifference(depth, depth_pred):													
	loss = torch.mean((depth - depth_pred)**2 / depth_pred)
	return loss

def RMSE(depth, depth_pred):              										
	loss = torch.sqrt(torch.mean((depth - depth_pred)**2))
	return loss

def RMSE_log(depth, depth_pred):                 										
	loss = torch.sqrt(torch.mean((torch.log(depth) - torch.log(depth_pred))**2))
	return loss

def ScaleInvariantRMSE(depth, depth_pred):		
	depth = torch.clamp(depth, min = 1e-8)
	depth_pred = torch.clamp(depth_pred, min = 1e-8)					
	d = torch.log(depth + 1e-8) - torch.log(depth_pred + 1e-8)
	loss = torch.mean((d)**2)

	relLoss = (torch.mean(d) ** 2 )
	return loss - relLoss

def Log10Error(depth, depth_pred):                               
	loss = torch.mean(torch.abs(torch.log10(depth) - torch.log10(depth_pred)))
	return loss

def _get_grad(img):																#-check correctness (gradient obtained by Sobel filter.)
	img = torch.mean(img, 1, True)
	fx = np.array([[1,0,-1],[2,0,-2],[1,0,-1]])
	conv1 = nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1, bias=False)
	weight = torch.from_numpy(fx).float().unsqueeze(0).unsqueeze(0)
	if img.is_cuda:	
		weight = weight.cuda()
	conv1.weight = nn.Parameter(weight)
	grad_x = conv1(img)

	fy = np.array([[1,2,1],[0,0,0],[-1,-2,-1]])
	conv2 = nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1, bias=False)
	weight = torch.from_numpy(fy).float().unsqueeze(0).unsqueeze(0)
	if img.is_cuda:
		weight = weight.cuda()
	conv2.weight = nn.Parameter(weight)
	grad_y = conv2(img)
	
	N, C,_,_ = img.size()
	return torch.cat((grad_y.view(C, -1), grad_x.view(C, -1)), dim=1)

def GradientLoss(depth, depth_pred): # The gradient loss is the L1 norm of the difference. -https://github.com/haofengac/MonoDepth-FPN-PyTorch/blob/master/README.md
	loss = torch.sum(torch.mean(torch.abs(_get_grad(depth) - _get_grad(depth_pred))))
	return loss

def SSIM(depth, depth_pred): 												#-check correctness
	C1 = 0.01 ** 2
	C2 = 0.03 ** 2

	mu_x = nn.AvgPool2d(3, 1)(depth)
	mu_y = nn.AvgPool2d(3, 1)(depth_pred)
	mu_x_mu_y = mu_x * mu_y
	mu_x_sq = mu_x.pow(2)
	mu_y_sq = mu_y.pow(2)

	sigma_x = nn.AvgPool2d(3, 1)(depth * depth) - mu_x_sq
	sigma_y = nn.AvgPool2d(3, 1)(depth_pred * depth_pred) - mu_y_sq
	sigma_xy = nn.AvgPool2d(3, 1)(depth * depth_pred) - mu_x_mu_y

	SSIM_n = (2 * mu_x_mu_y + C1) * (2 * sigma_xy + C2)
	SSIM_d = (mu_x_sq + mu_y_sq + C1) * (sigma_x + sigma_y + C2)
	SSIM = SSIM_n / SSIM_d

	return torch.mean(torch.clamp((1 - SSIM) / 2, 0, 1))

def BerHu(depth, depth_pred):
	absdiff = torch.abs(depth - depth_pred)
	C = 0.2*torch.max(absdiff).item()
	return torch.mean(torch.where(absdiff < C, absdiff,(absdiff*absdiff+C*C)/(2*C)))

class CustomLoss(nn.Module):
    """
    Class that, given the real and predicted depth, computes the loss.
    If the depth are of different dimension, scale to the smallest one. 

    Args:
        depth (torch.Tensor): the ground truth of the depth map
        depth_pred (torch.Tensor): the predicted depth map

    Return:
        loss (int): the computed loss between the depth and the depth_pred
    """
	
    def __init__(self, loss = 'Custom1'):
        super(CustomLoss, self).__init__()
        self.loss = loss

    def forward(self, depth, depth_pred):
        if depth.shape != depth_pred:
            depth_pred = transforms.Resize((np.min([depth.shape[2], depth_pred.shape[2]]), np.min([depth.shape[3], depth_pred.shape[3]])))(depth_pred)
            depth = transforms.Resize((np.min([depth.shape[2], depth_pred.shape[2]]), np.min([depth.shape[3], depth_pred.shape[3]])))(depth)

        if self.loss == 'Custom1':
            SSIM_weight = 0
            SSIM_loss = SSIM(depth, depth_pred)
            grad_weight = 1
            grad_loss = GradientLoss(depth, depth_pred)
            L1_weight = 0.1
            L1_loss = L1(depth, depth_pred)
    
            criterion = SSIM_weight * SSIM_loss + grad_weight * grad_loss + L1_weight * L1_loss
        elif self.loss == 'Custom2':
            criterion = BerHu(depth, depth_pred)
        elif self.loss == 'Custom3':
            SSIM_weight = 1
            SSIM_loss = SSIM(depth, depth_pred)
            L1_weight = 1
            L1_loss = L1(depth, depth_pred)

            criterion = SSIM_weight * SSIM_loss + L1_weight * L1_loss
		

        return criterion

class CustomLoss2:

	def __init__(self, loss):
		super(CustomLoss2, self).__init__()
		self.loss = loss
		self.available_losses = {'gradient-loss': GradientLoss}
	
	def forward(self, depth, depth_pred):

		if depth.shape != depth_pred:
			depth_pred = transforms.Resize((np.min([depth.shape[2], depth_pred.shape[2]]), np.min([depth.shape[3], depth_pred.shape[3]])))(depth_pred)
			depth = transforms.Resize((np.min([depth.shape[2], depth_pred.shape[2]]), np.min([depth.shape[3], depth_pred.shape[3]])))(depth)
		
		return self.available_losses[self.loss](depth, depth_pred)

