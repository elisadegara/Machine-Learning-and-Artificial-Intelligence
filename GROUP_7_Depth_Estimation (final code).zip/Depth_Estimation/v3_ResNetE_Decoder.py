import torch

import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F


class ResNetE_Decoder(nn.Module):
    def __init__(self):
        super(ResNetE_Decoder, self).__init__()
        
        self.name = "ResNetE_Decoder"

        resnet34 = models.resnet34(pretrained=True)
        self.layer0 = nn.Sequential(resnet34.conv1, resnet34.bn1, resnet34.relu, resnet34.maxpool)
        self.layer1 = resnet34.layer1
        self.layer2 = resnet34.layer2
        self.layer3 = resnet34.layer3
        self.layer4 = resnet34.layer4

        self.upconv1 = nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1) #256x8x8
        self.upconv2 = nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1) #128x16x16
        self.upconv3 = nn.ConvTranspose2d(384, 192, kernel_size=4, stride=2, padding=1) #64x32x32
        self.upconv4 = nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1) #32x64x64
        self.upconv5 = nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1) #16x128x128

        self.input_conv = nn.Conv2d(3, 16, kernel_size=3, padding=1)

        self.final_conv_1 = nn.Conv2d(80, 40, kernel_size=5, padding=2)
        self.final_conv_2 = nn.Conv2d(40, 20, kernel_size=7, padding=3)
        self.final_conv_3 = nn.Conv2d(20, 1, kernel_size=9, padding=4)


    def forward(self, x):
        input_x = x

        x = self.layer0(x) #64x32x32
        x = self.layer1(x) #64x32x32
        x_skip_1 = x
        x = self.layer2(x) #128x16x16
        x_skip_2 = x
        x = self.layer3(x) #256x8x8
        x_skip_3 = x
        x = self.layer4(x) #512x4x4

        x = F.relu(self.upconv1(x)) #256x8x8
        x = torch.cat([x, x_skip_3], dim=1) #512x8x8
        x = F.relu(self.upconv2(x)) #256x16x16
        x= torch.cat([x, x_skip_2], dim=1) #384x16x16
        x = F.relu(self.upconv3(x)) #192x32x32
        x = torch.cat([x, x_skip_1], dim=1) #256x32x32
        x = F.relu(self.upconv4(x)) #128x64x64
        x = F.relu(self.upconv5(x)) #64x128x128

        input_x = F.relu(self.input_conv(input_x))

        x = torch.cat([x, input_x], dim=1) #80x128x128

        x = F.relu(self.final_conv_1(x))
        x = F.relu(self.final_conv_2(x))
        x = F.relu(self.final_conv_3(x))

        return x
    