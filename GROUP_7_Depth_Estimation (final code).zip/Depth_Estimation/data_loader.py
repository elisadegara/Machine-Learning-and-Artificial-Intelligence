import os
import sys
import os.path
import numpy as np
import torch.utils.data as data
import h5py
from torchvision import transforms
import random
from PIL import Image

IMG_EXTENSIONS = ['.h5',]

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

def make_dataset(dir):
    images = []
    dir = os.path.expanduser(dir)
    for target in sorted(os.listdir(dir)):
        d = os.path.join(dir, target)
        if not os.path.isdir(d):
            continue
        for root, _, fnames in sorted(os.walk(d)):
            for fname in sorted(fnames):
                if is_image_file(fname):
                    path = os.path.join(root, fname)
                    item = (path)
                    images.append(item)
    return images

def h5_loader(path):
    h5f = h5py.File(path, "r")
    rgb = h5f['rgb']
    rgb = np.transpose(rgb, (1, 2, 0))
    depth = np.array(h5f['depth'])
    return rgb, depth

class NYUDataset(data.Dataset):
    def __init__(self, root, type, loader=h5_loader, transform = None):
        super().__init__()
        imgs = make_dataset(root)
        assert len(imgs)>0, "Found 0 images in subfolders of: " + root + "\n"
        print("Found {} images in {} folder.".format(len(imgs), type))
        self.root = root
        self.imgs = imgs
        self.loader = loader
        self.transform = transform

    def __getitem__(self, index):
        path = self.imgs[index]
        rgb, depth = self.loader(path)

        seed = random.randrange(sys.maxsize)

        if self.transform is None:
            self.transform = transforms.ToTensor()

        
        rgb = Image.fromarray(rgb, mode="RGB")
        depth = Image.fromarray(depth / 10)

        depth.convert("L")
        random.seed(seed)
        input_tensor = self.transform(rgb)
        random.seed(seed)
        depth_tensor = self.transform(depth)
        
        while input_tensor.dim() < 3:
            input_tensor = input_tensor.unsqueeze(0)
            depth_tensor = depth_tensor.unsqueeze(0)

        return input_tensor, depth_tensor

    def __len__(self):
        return len(self.imgs)