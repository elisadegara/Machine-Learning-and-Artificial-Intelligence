Auxiliary files: custom_loss.py, data_loader_reduced.py, train_functions.py, utils.py
Other files: README.md, requirements.txt
Results: model_results.ipynb
Models's files: DE_NoSkip.py, DenseNet_UNet.py, ResNet_UNet.py, v1_ResNetE_Decoder.py, v2_ResNetE_Decoder.py, v2_ResNetE_Decoder.py
Training files: DE_NoSkip_train.ipynb, DenseNet_UNet_train.ipynb, ResNet_UNet_train.ipynb, v1_ResNetE_Decoder_train.ipynb, v2_ResNetE_Decoder_train.ipynb, v2_ResNetE_Decoder_train.ipynb
